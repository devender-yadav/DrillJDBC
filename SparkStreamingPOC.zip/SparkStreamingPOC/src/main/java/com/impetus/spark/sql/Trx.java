package com.impetus.spark.sql;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class Trx
{
    public static void main(String[] args)
    {

        // String str =
        // "My most favorite fruit is [0], but I also like [1] and [3] adn [0]";
        // String[] fruits = { "Banana", "Orange", "Apple", "Grape" };
        //
        // for (int i = 0; i < fruits.length; i++)
        // {
        // str = str.replace("[" + i + "]", fruits[i]);
        // }
        // System.out.println(str);

        Map<String, String> props = new HashMap<String, String>();
       props.put("inputNum", "1");

props.put("inputJdbcUrl", "jdbc:hive2://IMPETUS-DSRV07.impetus.co.in:10000/default");
props.put("inputUserName", "idwblend");
props.put("inputPassword", "idwblend");
props.put("inputTableName", "d1");
props.put("inputStagingTargetType", "hivetable");
props.put("inputStagingTarget", "dev1");

props.put("targetNameNodeUrl", "hdfs://IMPETUS-DSRV07.impetus.co.in:8020");
props.put("targetJdbcUrl", "jdbc:hive2://IMPETUS-DSRV07.impetus.co.in:10000/default");
props.put("targetUserName", "idwblend");
props.put("targetPassword", "idwblend");

        InputStream in = Trx.class.getResourceAsStream("/subworkflowtemplate.xml");

        if (in != null)
        {
            try
            {
                DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
                DocumentBuilder builder = factory.newDocumentBuilder();
                Document doc = builder.parse(in);
                Element action = (Element) doc.getElementsByTagName("action").item(0);
                action.setAttribute("name", "name set");
                Element conf = (Element) doc.getElementsByTagName("configuration").item(0);
                Element property = (Element) conf.getElementsByTagName("property").item(0);
                
                if(props == null || props.isEmpty()){
                    conf.getParentNode().removeChild(conf);
                }else{
                    
                    for(Entry<String, String> entry : props.entrySet()){
                        Element propClone = (Element) property.cloneNode(true);
                        propClone.getElementsByTagName("name").item(0).setTextContent(entry.getKey());
                        propClone.getElementsByTagName("value").item(0).setTextContent(entry.getValue());
                        conf.appendChild(propClone);
                    }
                    conf.removeChild(property);
                }
               

                
             // write the content on console
                TransformerFactory transformerFactory = 
                TransformerFactory.newInstance();
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                System.out.println("-----------Modified File-----------");
                StreamResult consoleResult = new StreamResult(System.out);
                transformer.transform(source, consoleResult);
                
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

    }
    // public static Node buildSubworkflowAction(String name, String path,
    // Map<String, String> props, String okTo,
    // String errorTo) throws IDWCheckedException
    // {
    // InputStream in = OozieCompilerUtils.class
    // .getResourceAsStream(OozieCompilerUtils.OOZIE_SUB_WORKFLOW_XML_TEMPLATE);
    // if (in != null)
    // {
    // try
    // {
    // DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    // DocumentBuilder builder = factory.newDocumentBuilder();
    // Document doc = builder.parse(in);
    // Element action = (Element) doc.getElementsByTagName("action").item(0);
    // action.setAttribute("name", name);
    // Element conf = (Element)
    // doc.getElementsByTagName("configuration").item(0);
    // Node property = conf.getFirstChild();
    //
    // Node config = sqoop.getElementsByTagName("configuration").item(0);
    // Node prop1 = conf.getFirstChild();
    // if (properties != null && !properties.isEmpty())
    // {
    // for (String key : properties.keySet())
    // {
    // Node nuprop = prop1.cloneNode(true);
    // nuprop.getFirstChild().setTextContent(key);
    // nuprop.getLastChild().setTextContent(properties.get(key));
    // config.appendChild(nuprop);
    // }
    // }
    //
    // Node config = hive2.getElementsByTagName("configuration").item(0);
    // Node prop1 = config.getFirstChild();
    // if (properties != null && !properties.isEmpty())
    // {
    // for (String key : properties.keySet())
    // {
    // Node nuprop = prop1.cloneNode(true);
    // nuprop.getFirstChild().setTextContent(key);
    // nuprop.getLastChild().setTextContent(properties.get(key));
    // config.appendChild(nuprop);
    // }
    // }
    //
    // if (props == null || props.isEmpty())
    // {
    // conf.getParentNode().removeChild(conf);
    // }
    // else
    // {
    //
    // for (Map.Entry<String, String> entry : props.entrySet())
    // {
    // System.out.println(entry.getKey() + "/" + entry.getValue());
    // }
    //
    // Entry<String, String> entry = props.entrySet().iterator().next();
    //
    // Element property = (Element)
    // conf.getElementsByTagName("property").item(0);
    // property.getElementsByTagName("name").item(0).setTextContent(entry.getKey());
    // property.getElementsByTagName("value").item(0).setTextContent(entry.getValue());
    // }
    // Node appPath = doc.getElementsByTagName("app-path").item(0);
    // appPath.setTextContent(path);
    // Element ok = (Element) action.getElementsByTagName("ok").item(0);
    // ok.setAttribute("to", okTo);
    // Element error = (Element) action.getElementsByTagName("error").item(0);
    // error.setAttribute("to", errorTo);
    // return action;
    // }
    // catch (ParserConfigurationException e)
    // {
    // throw new
    // IDWCheckedException("Cannot parse java action node XML template", e);
    // }
    // catch (SAXException e)
    // {
    // throw new
    // IDWCheckedException("Cannot parse java action node XML template", e);
    // }
    // catch (IOException e)
    // {
    // throw new
    // IDWCheckedException("Cannot parse java action node XML template", e);
    // }
    // }
    // else
    // {
    // throw new
    // IDWCheckedException("Cannot load java action node XML template: "
    // + OozieCompilerUtils.OOZIE_SUB_WORKFLOW_XML_TEMPLATE);
    // }
    // }

}
