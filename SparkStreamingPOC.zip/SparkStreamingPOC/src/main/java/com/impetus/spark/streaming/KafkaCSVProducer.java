package com.impetus.spark.streaming;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import au.com.bytecode.opencsv.CSVReader;

public class KafkaCSVProducer
{

    private final static String KEY_TOPIC = "mytopic";

    private static final int FIELD_CREATED_DTM = 1;

    private static final int FIELD_SCRIPT_CODE = 0;

    private static final int FIELD_OPEN_PRICE = 3;

    private static final int FIELD_CURRENT_CLOSE_PRICE = 4;

    public KafkaCSVProducer(String fileName)
    {

        processCSV(fileName, KEY_TOPIC);
    }

    public KafkaCSVProducer(final String fileName, final String topic)
    {

        processCSV(fileName, topic);
    }

    public static void main(String[] args)
    {

        new KafkaCSVProducer("/home/impadmin/data2.csv");
        // new KafkaCSVProducer("/home/impadmin/address.csv");
    }

    private void processCSV(String fileName, String topic)
    {

        Properties props = new Properties();
        // props.put("metadata.broker.list",
        // "192.168.145.35:9092,192.168.145.59:9092,192.168.145.60:9092");
        props.put("metadata.broker.list", "localhost:9092");
        props.put("serializer.class", "kafka.serializer.StringEncoder");
        // props.put("partitioner.class",
        // "com.impetus.kafka.SimplePartitioner");
        props.put("request.required.acks", "1");

        ProducerConfig config = new ProducerConfig(props);
        Producer<String, String> producer = new Producer<String, String>(config);

        try
        {
            CSVReader reader = new CSVReader(new FileReader(validateFilePath(fileName)));
            String[] nextLine;

            do
            {
                while ((nextLine = reader.readNext()) != null)
                {

                    KeyedMessage<String, String> data = new KeyedMessage<String, String>(topic,
                            convertRowToJSON(nextLine));

                    producer.send(data);
                }
                reader = null;
                reader = new CSVReader(new FileReader(validateFilePath(fileName)));
            }
            while ((nextLine = reader.readNext()) != null);

            producer.close();

        }
        catch (Exception e)
        {
            System.out.println(e.toString());
            System.err.println("processCSV(): Caught Exception: " + e.getMessage());
        }
    }

    /**
     * Check to make sure the file path of the instances.csv file is valid.
     * 
     * @param filePath
     *            file path to validate.
     * @return the file path. It returns what was passed to it if valid.
     * @throws IOException
     *             file does not exist
     **/
    private static String validateFilePath(final String filePath) throws IOException
    {

        File file = new File(filePath);
        if (!file.exists())
        {
            throw new IOException("'" + filePath + "' is not a vaild file path.");
        }
        return filePath;
    }

    /**
     * Takes an single instance row and converts to JSON format.
     * 
     * @param row
     *            an single record in Array format.
     * @return JSON string
     **/
    public static String convertRowToJSON(final String[] row)
    {

        try
        {
            StringBuffer buff = new StringBuffer();
            buff.append(row[FIELD_SCRIPT_CODE]);
            buff.append(",");
            buff.append(row[FIELD_CREATED_DTM]);
            buff.append(",");
            buff.append(row[FIELD_OPEN_PRICE]);
            buff.append(",");
            buff.append(row[FIELD_CURRENT_CLOSE_PRICE]);
            return buff.toString();
        }
        catch (Exception e)
        {
            System.err.println("convertRowToJSON(): Caught Exception: " + e.getMessage());
        }
        return null;
    }

}