package com.impetus.spark.sql;

import java.util.HashMap;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.SQLContext;

import com.datastax.spark.connector.japi.CassandraJavaUtil;
import com.datastax.spark.connector.japi.SparkContextJavaFunctions;

public class SparkJoins
{
    public static void main(String args[]) throws InterruptedException
    {
        SparkConf conf = new SparkConf(true).setMaster("local").setAppName("spark").set("spark.executor.memory", "1g")
                .set("spark.cassandra.connection.host", "localhost")
                .set("spark.cassandra.connection.native.port", "9042")
                .set("spark.cassandra.connection.rpc.port", "9160");
        SparkContext ctx = new SparkContext(conf);
        SQLContext sqlContext = new org.apache.spark.sql.SQLContext(ctx);

        SparkContextJavaFunctions functions = CassandraJavaUtil.javaFunctions(ctx);

        // JavaRDD cassandraRowsRDD = functions.cassandraTable("sparktest",
        // "spark_person",
        // CassandraJavaUtil.mapRowTo(Person.class));
        // // persons from cassandra registered in a table
        // sqlContext.createDataFrame(cassandraRowsRDD,
        // Person.class).registerTempTable("person");

        HashMap<String, String> options1 = new HashMap<String, String>();
        options1.put("c_table", "spark_person");
        options1.put("keyspace", "sparktest");
        // address from hdfs registered in a table
        sqlContext.load("org.apache.spark.sql.cassandra", options1).registerTempTable("person");

        sqlContext.sql("select age + personName from person").show();
        sqlContext.sql("select * from person order by age asc offset 3 rows").show();


//        HashMap<String, String> options = new HashMap<String, String>();
//        options.put("header", "true");
//        // options.put("path", "hdfs://localhost:9000/address.csv");
//        options.put("path", "/home/impadmin/address.csv");
//
//        // address from hdfs registered in a table
//        sqlContext.load("com.databricks.spark.csv", options).registerTempTable("address");
//
//        sqlContext.sql("select * from address").show();
//
//        // sqlContext.sql("select sum(pin) from address").show();
//
//        sqlContext.sql("select p.personName, a.city, a.pin from person p join address a on p.personId = a.person_id")
//                .show();

    }
}
