package com.impetus.spark.sql;

import java.util.Arrays;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import com.datastax.spark.connector.japi.CassandraJavaUtil;
import com.datastax.spark.connector.japi.CassandraRow;
import com.datastax.spark.connector.japi.SparkContextJavaFunctions;

import scala.Tuple2;
import scala.collection.Seq;

public class WordCount {
    private static final FlatMapFunction<String, String> WORDS_EXTRACTOR = new FlatMapFunction<String, String>() {
        public Iterable<String> call(String s) throws Exception {
            return Arrays.asList(s.split(" "));
        }
    };

    private static final PairFunction<String, String, Integer> WORDS_MAPPER =
        new PairFunction<String, String, Integer>() {
            public Tuple2<String, Integer> call(String s) throws Exception {
                return new Tuple2<String, Integer>(s, 1);
            }
        };

    private static final Function2<Integer, Integer, Integer> WORDS_REDUCER =
        new Function2<Integer, Integer, Integer>() {
            public Integer call(Integer a, Integer b) throws Exception {
                return a + b;
            }
        };

    public static void main(String[] args) {
        // if (args.length < 1)
        // {
        // System.err.println("Please provide the input file full path as argument");
        // System.exit(0);
        // }

//        String[] jars = {"target/SparkStreamingPOC-1.0-SNAPSHOT-driver.jar"};
//        SparkConf conf =
//            new SparkConf().setAppName("WordCount").setMaster("yarn-cluster").setJars(jars)//.setMaster("yarn-cluster")
//                .set("spark.executor.memory", "1g").set("HADOOP_CONF_DIR", "/home/impadmin/hadoop-2.6.0/etc/hadoop");
        System.out.println("control passed: "+args[0]);
        JavaSparkContext context = new JavaSparkContext("yarn-cluster", "test");

        // SQLContext sqlContext = new SQLContext(context);
        //
        // DataFrame df = sqlContext.jsonFile("/home/impadmin/testsql");
        // df.show();
        // df.printSchema();
        // df.select("name").show();
        // df.select(df.col("name"), df.col("age").plus(1)).show();

        // long start = System.currentTimeMillis();
        // df.filter(df.col("age").gt(21)).show();
        // long end = System.currentTimeMillis() - start;
        // System.out.println("spark counted in: " + end);
        //
        // // Count people by age
        // df.groupBy("age").count().show();
        //
        // SparkContextJavaFunctions functions =
        // CassandraJavaUtil.javaFunctions(context);
        //
        // JavaRDD<CassandraRow> rdd = functions.cassandraTable("sparktest",
        // "SPARK_PERSON").distinct();
        //
        // long c = rdd.count();
        // System.out.println(c);

        JavaRDD<String> file = context.textFile("hdfs://192.168.41.51:9000/loremipsum.txt");
        JavaRDD<String> words = file.flatMap(WORDS_EXTRACTOR);
        JavaPairRDD<String, Integer> pairs = words.mapToPair(WORDS_MAPPER);
        JavaPairRDD<String, Integer> counter = pairs.reduceByKey(WORDS_REDUCER);

        counter.saveAsTextFile("hdfs://192.168.41.51:9000/yarn_output_"+System.currentTimeMillis());
    }
}
