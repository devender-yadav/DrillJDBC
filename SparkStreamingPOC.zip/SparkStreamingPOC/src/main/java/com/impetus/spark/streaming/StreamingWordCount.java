package com.impetus.spark.streaming;

import java.util.Arrays;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.lib.output.SequenceFileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.FlatMapFunction;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.PairFunction;
import org.apache.spark.streaming.Durations;
import org.apache.spark.streaming.api.java.JavaDStream;
import org.apache.spark.streaming.api.java.JavaPairDStream;
import org.apache.spark.streaming.api.java.JavaReceiverInputDStream;
import org.apache.spark.streaming.api.java.JavaStreamingContext;

import scala.Tuple2;

public class StreamingWordCount
{
    private static final FlatMapFunction<String, String> WORDS_EXTRACTOR = new FlatMapFunction<String, String>()
    {
        public Iterable<String> call(String s) throws Exception
        {
            return Arrays.asList(s.split(" "));
        }
    };

    private static final PairFunction<String, String, Integer> WORDS_MAPPER = new PairFunction<String, String, Integer>()
    {
        public Tuple2<String, Integer> call(String s) throws Exception
        {
            return new Tuple2<String, Integer>(s, 1);
        }
    };

    private static final Function2<Integer, Integer, Integer> WORDS_REDUCER = new Function2<Integer, Integer, Integer>()
    {
        public Integer call(Integer a, Integer b) throws Exception
        {
            return a + b;
        }
    };

    public static void main(String[] args)
    {

        SparkConf conf = new SparkConf().setMaster("local[2]").setAppName("StreamingWordCount");
        JavaStreamingContext jssc = new JavaStreamingContext(conf, Durations.seconds(1));

        JavaReceiverInputDStream<String> lines = jssc.socketTextStream("localhost", 9999);

        JavaDStream<String> words = lines.flatMap(WORDS_EXTRACTOR);
        JavaPairDStream<String, Integer> pairs = words.mapToPair(WORDS_MAPPER);
        JavaPairDStream<String, Integer> counter = pairs.reduceByKey(WORDS_REDUCER);

        counter.print(100000);
        Class<? extends OutputFormat<?, ?>> outputFormatClass = (Class<? extends OutputFormat<?, ?>>) (Class<?>) TextOutputFormat.class;

        // Configuration config = new Configuration();
        // config.set("fs.default.name", "hdfs://localhost:9000/");

        // config.addResource(new
        // Path("/home/impadmin/hadoop-2.5.2/etc/hadoop/core-site.xml"));
        // config.addResource(new
        // Path("/home/impadmin/hadoop-2.5.2/etc/hadoop/hdfs-site.xml"));

        counter.saveAsNewAPIHadoopFiles("hdfs://192.168.41.51:9000/stream/myapp", "txt", Text.class, Text.class,
                outputFormatClass);
        // counter.saveAsNewAPIHadoopFiles(prefix, suffix, keyClass, valueClass,
        // outputFormatClass, conf);
        // counter.saveAsHadoopFiles("hdfs://localhost:9000/test", ".txt")
        jssc.start();
        jssc.awaitTermination();

    }
}
