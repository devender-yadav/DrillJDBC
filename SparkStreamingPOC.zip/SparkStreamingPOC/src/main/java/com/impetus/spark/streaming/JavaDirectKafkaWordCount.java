package com.impetus.spark.streaming;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Arrays;
import java.util.regex.Pattern;

import scala.Tuple2;

import com.google.common.collect.Lists;

import kafka.serializer.StringDecoder;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.OutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.function.*;
import org.apache.spark.streaming.api.java.*;
import org.apache.spark.streaming.kafka.KafkaUtils;
import org.apache.spark.streaming.Durations;

/**
 * Consumes messages from one or more topics in Kafka and does wordcount. Usage:
 * DirectKafkaWordCount <brokers> <topics> <brokers> is a list of one or more
 * Kafka brokers <topics> is a list of one or more kafka topics to consume from
 * 
 * Example: $ bin/run-example streaming.KafkaWordCount
 * broker1-host:port,broker2-host:port topic1,topic2
 */

public final class JavaDirectKafkaWordCount
{
    private static final Pattern SPACE = Pattern.compile(" ");

    public static void main(String[] args)
    {
        if (args.length < 2)
        {
            System.err.println("Usage: DirectKafkaWordCount <brokers> <topics>\n"
                    + "  <brokers> is a list of one or more Kafka brokers\n"
                    + "  <topics> is a list of one or more kafka topics to consume from\n\n");
            System.exit(1);
        }

        // StreamingExamples.setStreamingLogLevels();

        String brokers = args[0];
        String topics = args[1];

        // Create context with 2 second batch interval
        SparkConf sparkConf = new SparkConf().setMaster(/* "spark://impetus-1413U:7077" */"local[*]").setAppName(
                "JavaDirectKafkaWordCount");
        JavaStreamingContext jssc = new JavaStreamingContext(sparkConf, Durations.seconds(2));

        HashSet<String> topicsSet = new HashSet<String>(Arrays.asList(topics.split(",")));
        HashMap<String, String> kafkaParams = new HashMap<String, String>();
        kafkaParams.put("metadata.broker.list", brokers);

        Class<? extends OutputFormat<?, ?>> outputFormatClass = (Class<? extends OutputFormat<?, ?>>) (Class<?>) TextOutputFormat.class;

        // Create direct kafka stream with brokers and topics
        JavaPairInputDStream<String, String> messages = KafkaUtils.createDirectStream(jssc, String.class, String.class,
                StringDecoder.class, StringDecoder.class, kafkaParams, topicsSet);
        
        messages.print();
        messages.saveAsNewAPIHadoopFiles("hdfs://192.168.41.51:9000/kafka_stream1/myapp", "txt", Text.class,
                Text.class, outputFormatClass);

        // Get the lines, split them into words, count the words and print
//        JavaDStream<String> lines = messages.map(new Function<Tuple2<String, String>, String>()
//        {
//            public String call(Tuple2<String, String> tuple2)
//            {
//                return tuple2._2();
//            }
//        });
//        JavaDStream<String> words = lines.flatMap(new FlatMapFunction<String, String>()
//        {
//            public Iterable<String> call(String x)
//            {
//                return Lists.newArrayList(SPACE.split(x));
//            }
//        });
//        JavaPairDStream<String, Integer> wordCounts = words.mapToPair(new PairFunction<String, String, Integer>()
//        {
//            public Tuple2<String, Integer> call(String s)
//            {
//                return new Tuple2<String, Integer>(s, 1);
//            }
//        }).reduceByKey(new Function2<Integer, Integer, Integer>()
//        {
//            public Integer call(Integer i1, Integer i2)
//            {
//                return i1 + i2;
//            }
//        });

        // if ((int)(long)wordCounts.count(). > 0)
//        {
//            wordCounts.print();
//            wordCounts.count().print();
//            wordCounts.saveAsNewAPIHadoopFiles("hdfs://192.168.41.51:9000/kafka_stream1/myapp", "txt", Text.class,
//                    Text.class, outputFormatClass);
//        }

        // Start the computation
        jssc.start();
        jssc.awaitTermination();
    }
}