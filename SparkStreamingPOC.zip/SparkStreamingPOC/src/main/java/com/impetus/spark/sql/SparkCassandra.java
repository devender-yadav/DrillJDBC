package com.impetus.spark.sql;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.commons.lang.StringUtils;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
//import org.apache.spark.api.java.JavaRDD;
//import org.apache.spark.api.java.function.Function;
//import org.apache.spark.storage.StorageLevel;
//
//import com.datastax.spark.connector.japi.CassandraJavaUtil;
//import com.datastax.spark.connector.japi.CassandraRow;
//import com.datastax.spark.connector.japi.SparkContextJavaFunctions;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

import scala.collection.Seq;
import scala.reflect.ClassTag;

import com.datastax.spark.connector.japi.CassandraJavaUtil;
import com.datastax.spark.connector.japi.CassandraRow;
import com.datastax.spark.connector.japi.SparkContextJavaFunctions;
import com.datastax.spark.connector.japi.rdd.CassandraJavaRDD;

public class SparkCassandra
{
    static EntityManagerFactory emf;

    static EntityManager em;

    public static void main(String args[]) throws InterruptedException
    {
//         emf = Persistence.createEntityManagerFactory("spark-test");
//         em = emf.createEntityManager();
//         init();
//        
//         em.close();
//         emf.close();

        SparkConf conf = new SparkConf(true).setMaster("local").setAppName("spark")
                .set("spark.executor.memory", "1g").set("spark.cassandra.connection.host", "localhost")
                .set("spark.cassandra.connection.native.port", "9042")
                .set("spark.cassandra.connection.rpc.port", "9160");
        SparkContext ctx = new SparkContext(conf);
//        SparkContextJavaFunctions functions = CassandraJavaUtil.javaFunctions(ctx);
        // functions.cassandraTable("sparktest", "SPARK_PERSON",
        // mapColumnTo(Person.class));
        
//        CassandraJavaRDD<CassandraRow>  mCassandraRDD = functions.cassandraTable("sparktest", "spark_person");   
//        
//        mCassandraRDD.map(new Function<CassandraRow, Person>() {
//
//            public Person call(CassandraRow row) throws Exception {
//                Person mObject= new Person();
//                mObject.setPersonId(row.getString("M_ID"));
//                mObject.setPersonName(row.getString("m_name"));
//                return mObject;
//            }
//
//        });
//        JavaSQLContext sqlCtx = new JavaSQLContext(ctx);
//        JavaSchemaRDD schemaMObject = sqlCtx.applySchema(mCassandraRDD , Person.class);
//        schemaMatter.registerTempTable("MOBJECT_SPARK");
//
//        JavaSchemaRDD johnRDD = sqlCtx.sql("SELECT * FROM MOBJECT_SPARK WHERE name='john'");
//        System.out.println("Count=["+johnRDD.count()+"]");
//        
        
        
        
        
        
        
        
        
//        JavaRDD<Person> ser = functions.cassandraTable("sparktest", "spark_person", CassandraJavaUtil.mapRowTo(Person.class));
//        
//        JavaRDD<String> cassandraRowsRDD = functions.cassandraTable("sparktest", "spark_person").map(
//         new Function<CassandraRow, String>()
//         {
//         public String call(CassandraRow cassandraRow) throws Exception
//         {
//         return cassandraRow.toString()+cassandraRow.columnNames();
//         }
//         });
//         System.out.println("Data as CassandraRows: \n" +
//         StringUtils.join(cassandraRowsRDD.toArray(), "\n"));
         
         
//        SQLContext sqlContext1 = new org.apache.spark.sql.SQLContext(ctx);
//        sqlContext1.createDataFrame(ser, Person.class).show();
//        //
//        DataFrame df1 = sqlContext1.createDataFrame(cassandraRowsRDD, Person.class);
//        System.out.println("select * equivalent: ");
//        df1.show();

        // JavaRDD<CassandraRow> rdd = functions.cassandraTable("sparktest",
        // "SPARK_PERSON").distinct();
        // // rdd.persist(StorageLevel.MEMORY_ONLY());
        // long start = System.currentTimeMillis();
        // long c = rdd.count();
        // long end = System.currentTimeMillis() - start;
        // System.out.println("spark counted in: " + end);
        // System.out.println(c);
        //
        // long start1 = System.currentTimeMillis();
        // long c1 = rdd.count();
        // long end1 = System.currentTimeMillis() - start1;
        // System.out.println("spark counted in: " + end1);
        //
        // // rdd.unpersist();
        // long start2 = System.currentTimeMillis();
        // long c2 = rdd.count();
        // long end2 = System.currentTimeMillis() - start2;
        // System.out.println("spark counted in: " + end2);
        // JavaRDD<CassandraRow> cassandraRdd =
        // functions.cassandraTable("sparktest", "SPARK_PERSON").select("AGE");

        List<Person> persons = Arrays.asList(person("a", 35, "Tyrion", 10000.0), person("b", 25, "Robb", 50000.0),
                person("c", 20, "Karthik", 10000.0), person("d", 21, "Pragalbh", 10000.0),
                person("e", 21, "Amit", 10000.0), person("f", 20, "Dev", 10000.0));
        
//        persons.get(0).setPerson(persons.get(1));

        // List<Integer> data = Arrays.asList(1,2,3,4,5);

        // ClassTag<Integer> evidence$1 = new ClassTag<Integer>(Integer.class);
        // ClassTag<Integer> tag = scala.reflect.ClassTag$.MODULE$.apply(Integer.class);
        Seq<Person> s = scala.collection.JavaConversions.asScalaBuffer(persons).toList();
        ClassTag<Person> tag = scala.reflect.ClassTag$.MODULE$.apply(Person.class);
        JavaRDD<Person> personRDD = ctx.parallelize(s, 1, tag).toJavaRDD();
        System.out.println(personRDD.count());
        System.out.println(personRDD.first().getPersonName());

        SQLContext sqlContext = new org.apache.spark.sql.SQLContext(ctx);

        DataFrame df = sqlContext.createDataFrame(personRDD, Person.class);
        df.registerTempTable("person");
        df.show();
        DataFrame df1;
        long count = df.count();
        int limit = 6;
        while(count > 0){
            df1 = df.limit(limit);
            df1.show();//process
            df = df.except(df1);
            count = count - limit;
        }
        
        System.out.println(df.count());
        
        
        
        sqlContext.sql("select count(*) from person");
        System.out.println("select * equivalent: ");
        df.show();
//        System.out.println("print schema: ");
//        df.printSchema();
//        System.out.println("select name:");
//        df.select("personName").show();
//        System.out.println("select name and (age + 1)");
//        df.select(df.col("personName"), df.col("age").plus(1)).show();
//
//        long start = System.currentTimeMillis();
//        System.out.println("select * where age > 21 equivalent");
//        df.filter(df.col("age").gt(21)).show();
//        long end = System.currentTimeMillis() - start;
//        System.out.println("spark counted in: " + end);
//
//        // Count people by age
//        System.out.println("select count(*) group by age");
//        df.groupBy("age").count().show();
//
//        df.filter(df.col("age").gt(21)).registerTempTable("temp");
//
//        DataFrame x = sqlContext.sql("select age from temp");
//        System.out.println("filtered data: ");
//        x.show();
//        Map<String, String> options = new HashMap();
//        options.put("c_table", "ins");
//        options.put("keyspace", "sparktest");
        // options.put("path", "/home/impadmin/deleteparquet");
        // x.save("org.apache.spark.sql.cassandra", SaveMode.Append, options);
        // df.saveAsParquetFile("/home/impadmin/deleteparquet");

//        CassandraJavaUtil.javaFunctions(personRDD)
//                .writerBuilder("sparktest", "spark_person", CassandraJavaUtil.mapToRow(Person.class)).saveToCassandra();
//        cassandraRowsRDD.saveAsTextFile("/home/impadmin/deletethis");

    }

    public static void init() throws InterruptedException
    {
         createPerson("1", 20, "Amit", 100.0);
         createPerson("2", 10, "Dev", 200.0);
         createPerson("3", 30, "Karthik", 300.0);
         createPerson("4", 40, "Pragalbh", 400.0);
//        long start = System.currentTimeMillis();
//        for (int i = 0; i < 1000000; i++)
//        {
//            createPerson("\"" + (i + 1) + "\"", 20, "Karthik" + "\"" + (i + 1) + "\"", 100.0);
//            if (i % 1000 == 0)
//            {
//                long end = System.currentTimeMillis() - start;
//                System.out.println("inserted: " + i + " in: " + end);
//                em.clear();
//            }
//        }
    }

    public static void createPerson(String id, int age, String name, Double salary)
    {
        Person person = new Person();
        person.setAge(age);
        person.setPersonId(id);
        person.setPersonName(name);
        person.setSalary(salary);
        em.persist(person);
    }

    public static Person person(String id, int age, String name, Double salary)
    {
        Person person = new Person();
        person.setAge(age);
        person.setPersonId(id);
        person.setPersonName(name);
        person.setSalary(salary);
        return person;
    }
}
