package com.impetus.spark.sql;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.hive.HiveContext;

import scala.collection.Iterator;

public class SparkHive
{
    public static void main(String[] args) {
        SparkConf conf = new SparkConf(true).setMaster("local").setAppName("spark")
                .set("spark.executor.memory", "1g");
        SparkContext sc = new SparkContext(conf);
        HiveContext hc = new HiveContext(sc);
        System.out.println(hc.hiveconf().getAllProperties());
        DataFrame df = hc.table("userdb.employee");
        df.show();
        df.registerTempTable("emp_51");
        System.out.println("success");
        hc.clearCache();
//        hc.sparkContext().cl
        hc.setConf("hive.metastore.uris", "thrift://impetus-dsrv14.impetus.co.in:9083");
//        System.out.println(hc.hiveconf().getAllProperties());
//        scala.collection.immutable.Map<String, String> cfs = hc.getAllConfs();
        
//        Iterator<String> s = cfs.keys().iterator();
//        while(s.hasNext()){
//            String str = s.next();
//            System.out.println("key: "+str+"     val: "+cfs.get(str));
//        }
//        
        
//        try {
//            Class.forName("org.apache.hive.jdbc.HiveDriver");
//        } catch (ClassNotFoundException e) {
//            e.printStackTrace();
//        }
//        Map<String, String> options = new HashMap<String, String>();
//        String jdbc = "jdbc:hive2://localhost:10000/userdb";
//        options.put("url", jdbc);
//        options.put("dbtable", "employee");
//        hc.load("jdbc", options).registerTempTable("empl");
//        
//        DataFrame df = hc.sql("select * from empl limit 10");
//        df.show();
        
//        df.saveAsTable("spark_src");history
//        Map<String, String> options1 = new HashMap<String, String>();
//        options1.put("url", jdbc);
//        options1.put("dbtable", "empl");
//        df.save("org.apache.hive.jdbc.HiveDriver", SaveMode.Overwrite, options1);
        
//        hc.table("src").show();
        
         df = hc.sql("show tables");
         df.show();
         df.registerTempTable("cata_43");
         hc.sql("show tables").show();
//         df.saveAsTable("from_spark_1");
//         df.insertInto("test_spark.employee_1", false);
        System.out.println("success");
        
//        df.save
    }
}
