package com.impetus.spark.sql;

import java.util.HashMap;
import java.util.Map;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

public class SparkHiveJDBC
{
    public static void main(String[] args)
    {
        SparkConf conf = new SparkConf(true).setMaster("local[*]").setAppName("spark")
                .set("spark.executor.memory", "1g");
        SparkContext sc = new SparkContext(conf);
        SQLContext sqlContext = new SQLContext(sc);
        
         try {
         Class.forName("org.apache.hive.jdbc.HiveDriver");
         } catch (ClassNotFoundException e) {
         e.printStackTrace();
         }
         
         Map<String, String> options = new HashMap<String, String>();
         String jdbc = "jdbc:hive2://localhost:10000/testdb";
         options.put("url", jdbc);
         options.put("dbtable", "orders");
         sqlContext.load("jdbc", options).registerTempTable("orders");
        
         DataFrame df = sqlContext.sql("select `orders.phone` from orders");
         
         df.show();
         
         for(String c : df.columns()){
             System.out.println(c);
         }

//        df.insertIntoJDBC("jdbc:hive2://localhost:10000/test_spark", "employee_1", false);
        System.out.println("success");

        // df.save
    }
}
