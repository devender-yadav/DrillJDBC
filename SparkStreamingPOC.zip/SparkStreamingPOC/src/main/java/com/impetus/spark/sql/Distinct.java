package com.impetus.spark.sql;

import java.util.HashMap;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;

public class Distinct
{
    public static void main(String[] args) {
        SparkConf conf = new SparkConf(true).setMaster("local").setAppName("spark")
                .set("spark.executor.memory", "1g");
        SparkContext sc = new SparkContext(conf);
        
        SQLContext sqlContext = new SQLContext(sc);        
        HashMap<String, String> options = new HashMap<String, String>();
        options.put("header", "true");
        options.put("path", "/home/impadmin/address.csv");
        DataFrame df = sqlContext.load("com.databricks.spark.csv", options);
        df.registerTempTable("mytable");
        StringBuilder query = new StringBuilder("SELECT");
        String keyword = "person";
        for(String col:df.columns()){
            query.append(" ");
            if(col.equals(keyword)){
                query.append(col);
            }
            else{
                query.append("first("+col+") as "+ col);
            }
            query.append(",");
        }
        query.deleteCharAt(query.length()-1);
        query.append(" FROM mytable GROUP BY "+keyword);
        sqlContext.sql(query.toString()).save("/home/impadmin/"+System.currentTimeMillis()+".csv", "com.databricks.spark.csv");
        System.out.println(query);
//        df.save("hdfs://192.168.145.43:8020/user/idwblend/dev/"+System.currentTimeMillis()+".csv");
    }
}
