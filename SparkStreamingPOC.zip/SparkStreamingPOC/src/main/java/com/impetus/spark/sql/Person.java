package com.impetus.spark.sql;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.impetus.kundera.index.Index;
import com.impetus.kundera.index.IndexCollection;

@Entity
@Table(name = "spark_person")
@IndexCollection(columns = { @Index(name = "personName"), @Index(name = "age"), @Index(name = "salary") })
public class Person implements Serializable
{
    /** The person id. */
    @Id
//    @Column(name = "PERSON_ID")
    private String personId;

    /** The person name. */
//    @Column(name = "PERSON_NAME")
    private String personName;

    /** The age. */
//    @Column(name = "AGE")
    private Integer age;

    /** The salary. */
//    @Column(name = "SALARY")
    private Double salary;
    
//    private Person person;
//
//    public Person getPerson()
//    {
//        return person;
//    }
//
//    public void setPerson(Person person)
//    {
//        this.person = person;
//    }

    public String getPersonId()
    {
        return personId;
    }

    public void setPersonId(String personId)
    {
        this.personId = personId;
    }

    public String getPersonName()
    {
        return personName;
    }

    public void setPersonName(String personName)
    {
        this.personName = personName;
    }

    public Integer getAge()
    {
        return age;
    }

    public void setAge(Integer age)
    {
        this.age = age;
    }

    public Double getSalary()
    {
        return salary;
    }

    public void setSalary(Double salary)
    {
        this.salary = salary;
    }


}
