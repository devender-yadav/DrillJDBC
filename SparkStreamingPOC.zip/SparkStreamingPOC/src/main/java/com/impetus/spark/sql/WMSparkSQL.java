package com.impetus.spark.sql;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;

import org.apache.spark.Accumulator;
import org.apache.spark.AccumulatorParam;
import org.apache.spark.Partition;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.hive.HiveContext;

public class WMSparkSQL implements Serializable
{

    class IntegerAccumulatorParam implements AccumulatorParam<Integer>, Serializable
    {
        public Integer zero(Integer initialValue)
        {
            return initialValue;
        }

        public Integer addAccumulator(Integer v1, Integer v2)
        {
            return v1 + v2;
        }

        public Integer addInPlace(Integer v1, Integer v2)
        {
            v1 = v1 + v2;
            return v1;
        }
    }

    public class MyVoidFunction implements VoidFunction<Row>, Serializable
    {

        private Integer msgCounter;

        private Boolean flag;

        private Accumulator<Integer> count;

        public Integer getMsgCounter()
        {
            return msgCounter;
        }

        public void setMsgCounter(Integer msgCounter)
        {
            this.msgCounter = msgCounter;
        }

        public Boolean getFlag()
        {
            return flag;
        }

        public void setFlag(Boolean flag)
        {
            this.flag = flag;
        }

        public Accumulator<Integer> getCount()
        {
            return count;
        }

        public void setCount(Accumulator<Integer> count)
        {
            this.count = count;
        }

        public MyVoidFunction(Integer msgCounter, Boolean flag, Accumulator<Integer> count)
        {
            super();
            this.msgCounter = msgCounter;
            this.flag = flag;
            this.count = count;
        }

        public void call(Row row) throws Exception
        {

            Integer v_i_item_id = (Integer) row.get(0);
            // INSERT INTO SALES_MSGS VALUES (msgCounter , 'inside cursor');

            if (flag == true)
            {
                msgCounter = msgCounter + v_i_item_id * 10;
            }
            else
            {
                msgCounter = msgCounter + v_i_item_id;
            }

            if (msgCounter % 2 == 0)
            {
                flag = true;
            }
            else
            {
                flag = false;
            }
            count.add(1);
        }
    }

    public static void main(String[] args) throws Exception
    {

        SparkConf sparkConf = new SparkConf().setAppName("JavaSparkSQL")
        /* .setMaster("spark://impetus-D912.impetus.co.in:7077") */;
        SparkContext sc = new SparkContext(sparkConf);
        HiveContext hiveContext = new HiveContext(sc);

        /*
         * Sparkspsql hi = new Sparkspsql(hiveContext, dataSourceBean,
         * commonEDWUDFManager, edwDBMetaStore); hi.execute();
         */

        String query = args[0];

        if (query == null || query.length() <= 0)
        {
            System.out.println("Please pass valid query as argument");
            System.exit(1);
        }

        try
        {
            System.out.println("=== hiveContext ===" + hiveContext);

            DataFrame teenagers2 = hiveContext.sql(query);
            // ######################################################################
            WMSparkSQL x = new WMSparkSQL();
            AccumulatorParam<Integer> param = x.new IntegerAccumulatorParam();
            final Accumulator<Integer> counter = sc.accumulator(0, "counter", param);
            // ######################################################################
            List<String> teenagerNames = teenagers2.toJavaRDD().map(new Function<Row, String>()
            {
                public String call(Row row)
                {
                    counter.add(1);
                    return "id: " + row.getInt(0) + " name : " + row.getString(1);
                }
            }).collect();

            for (String name : teenagerNames)
            {
                System.out.println(name);
            }
            System.out.println("count : " + counter.value());
            // ######################################################################
            Integer msgCounter = 10;
            Boolean flag = false;
            WMSparkSQL.MyVoidFunction myVoidFunction = x.new MyVoidFunction(msgCounter, flag, counter);

            teenagers2.toJavaRDD().foreach(myVoidFunction);
            
            ////////////////
            JavaRDD<Row> rdd = teenagers2.toJavaRDD();
            List<Partition> parts = rdd.partitions();
            
            for(Partition p : parts){
                int idx = p.index();
                
//                rdd.mapPartitionsWithIndex(a -> if (a._1 == idx) a._2 else Iterator()  , true);
            }
            
            ///////////////
            msgCounter = myVoidFunction.getMsgCounter();
            System.out.println("count : " + counter.value());
            System.out.println("msgCounter : " + msgCounter);

            // ######################################################################
            teenagers2.toJavaRDD().saveAsTextFile("/tmp1");
            sc.stop();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}