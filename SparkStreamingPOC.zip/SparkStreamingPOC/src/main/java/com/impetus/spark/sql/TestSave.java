package com.impetus.spark.sql;

import java.util.Arrays;
import java.util.List;

import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.DataFrame;
import org.apache.spark.sql.SQLContext;
import org.apache.spark.sql.SaveMode;

import scala.collection.Seq;
import scala.reflect.ClassTag;

public class TestSave
{
    public static void main(String args[])
    {
        SparkConf conf = new SparkConf(true).setMaster("local").setAppName("spark");
        SparkContext ctx = new SparkContext(conf);
        
        
        List<Person> persons = Arrays.asList(person("a", 35, "Tyrion", 10000.0), person("b", 25, "Robb", 50000.0),
                person("c", 20, "Karthik", 10000.0), person("d", 21, "Pragalbh", 10000.0),
                person("e", 21, "Amit", 10000.0), person("f", 20, "Dev", 10000.0));
        
//        persons.get(0).setPerson(persons.get(1));

        Seq<Person> s = scala.collection.JavaConversions.asScalaBuffer(persons).toList();
        ClassTag<Person> tag = scala.reflect.ClassTag$.MODULE$.apply(Person.class);
        JavaRDD<Person> personRDD = ctx.parallelize(s, 1, tag).toJavaRDD();
        System.out.println(personRDD.count());
        System.out.println(personRDD.first().getPersonName());

        SQLContext sqlContext = new org.apache.spark.sql.SQLContext(ctx);

        DataFrame df = sqlContext.createDataFrame(personRDD, Person.class);
        df.registerTempTable("person");
        sqlContext.sql("select count(*) from person");
        System.out.println("select * equivalent: ");
        df.show();
        
        //save to HDFS
        String url = "hdfs://192.168.41.51:9000/saveData";
        df.save(url, "json", SaveMode.Overwrite);
        System.out.println("done");
    }
    

    public static Person person(String id, int age, String name, Double salary)
    {
        Person person = new Person();
        person.setAge(age);
        person.setPersonId(id);
        person.setPersonName(name);
        person.setSalary(salary);
        return person;
    }
}
